const usersRoute = require('./user');
const placesRoute = require('./places');

module.exports = function(app) {
  app.use('/api/project', usersRoute)
  app.use('/api/project', placesRoute)
}
