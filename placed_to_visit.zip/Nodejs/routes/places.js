const express = require('express');
const router = express.Router();
const placesController = require('../controllers/places')
const { verifyToken } = require('./../middlewares/verifyToken')

router.get('/fetch/places', verifyToken, placesController.fetchPlaces);
router.post('/add/places', verifyToken, placesController.addPlaces);
router.post('/edit/places/:place_id', verifyToken, placesController.editPlaces);

module.exports = router;
