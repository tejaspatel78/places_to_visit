'use strict'

require('../models/user')
const { pino, connect, bcrypt } = require('./../lib/utils')
const logger = pino({ level: 'debug' });

const insertUserData = async (reqPayload) => {
    try {
        logger.debug('insertUserData() reqPayload: %j', reqPayload)
        const db = await connect('Demo_Db')
        const userdataModel = db.model('users')
        const user = await userdataModel.find({ email: reqPayload.email })
        if (user.length > 0) {
            return 'User already exists'
        }
        const response = await userdataModel.insertMany(reqPayload)
        return response
    } catch (error) {
        logger.warn(`Error while insertUserData(). Error = %j %s`, error, error)
        throw error
    }
}

const userLogin = async (reqPayload) => {
    try {
        logger.debug('userLogin() reqPayload: %j', reqPayload)
        const db = await connect('Demo_Db')
        const userdataModel = db.model('users')
        const user = await userdataModel.find({ email: reqPayload.email })
        if (user.length === 0) {
            return 'User not exists, Please register !'
        }
        if(!bcrypt.compareSync(reqPayload.password, user[0].password)) {
            return 'The password is invalid'
        }
        return user
    }
    catch (error) {
        logger.warn(`Error while userLogin(). Error = %j %s`, error, error)
        throw error
    }
}

module.exports = {
    insertUserData,
    userLogin
}