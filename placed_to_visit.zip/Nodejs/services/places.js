'use strict'

require('../models/places')
const { pino, connect, bcrypt } = require('./../lib/utils')
const logger = pino({ level: 'debug' });

const fetchPlaces = async (userCode, start, limit) => {
    try {
        logger.debug('fetchPlaces() userCode: %s, start: %s, limit:%s', userCode, start, limit)
        const db = await connect('Demo_Db')
        const placesModel = db.model('places')
        const placesDetail = await placesModel.find({ created_by: userCode }).sort({created_on : -1}).skip(start).limit(limit)
        return placesDetail
    } catch (error) {
        logger.warn(`Error while fetchPlaces(). Error = %j %s`, error, error)
        throw error
    }
}

const addPlaces = async (reqPayload, userCode) => {
    try {
        logger.debug('addPlaces() reqPayload: %j, userCode: %s', reqPayload, userCode)
        const db = await connect('Demo_Db')
        const placesModel = db.model('places')
        const response = await placesModel.insertMany({
            name: reqPayload.name,
            city: reqPayload.city,
            pincode: reqPayload.pincode,
            ratings: reqPayload.ratings,
            location: reqPayload.location,
            created_by: userCode
        })
        return response
    } catch (error) {
        logger.warn(`Error while addPlaces(). Error = %j %s`, error, error)
        throw error
    }
}

const editPlaces = async (reqPayload, placeId, userCode) => {
    try {
        logger.debug('editPlaces() reqPayload: %j, placeId: %s', reqPayload, placeId)
        const db = await connect('Demo_Db')
        const placesModel = db.model('places')
        const response = await placesModel.update({ place_id: placeId, updated_by: userCode }, {
            $set: {
                name: reqPayload.name,
                city: reqPayload.city,
                pincode: reqPayload.pincode,
                ratings: reqPayload.ratings,
                location: reqPayload.location,
            }
        })
        return response
    } catch (error) {
        logger.warn(`Error while editPlaces(). Error = %j %s`, error, error)
        throw error
    }
}

module.exports = {
    fetchPlaces,
    addPlaces,
    editPlaces
}