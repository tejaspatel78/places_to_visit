'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema
require('mongoose-long')(mongoose)
const SchemaTypes = mongoose.Schema.Types
const { autoIncrement } = require('./../lib/utils')

const placesSchema = new Schema({
  place_id: {
    type: SchemaTypes.Long,
    required: true
  },
  name: {
    type: String,
    required: false
  },
  city: {
    type: String,
    required: true
  },
  pincode: {
    type: String,
    required: true
  },
  ratings: {
    type: Number,
    required: true
  },
  location: {
    type: String
  },
  created_by: {
    type: Number,
    required: true
  },
  created_on: {
    type: Date,
    default: Date.now
  }
})

placesSchema.plugin(autoIncrement.plugin, {
  model: 'places',
  field: 'place_id',
  startAt: 1
})

module.exports = mongoose.model('places', placesSchema)
