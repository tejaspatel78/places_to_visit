const placesService = require('../services/places')
const httpStatusCode = require('http-status-codes')
const { responseGenerators, pino } = require('./../lib/utils')
const logger = pino({ level: 'debug' });

const fetchPlaces = async (req, res) => {
    try {
        const userCode = req.headers.user_code
        const start = Number(req.query.start)
        const limit = Number(req.query.limit)
        const response = await placesService.fetchPlaces(userCode, start, limit)
        return res.status(httpStatusCode.OK).send(responseGenerators(response, httpStatusCode.OK, 'Places fetched successfully', false))
    } catch (error) {
        logger.warn(`Error while fetch places. Error: %j %s`, error, error)
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, 'Error while fetch places', true))
    }
}

const addPlaces = async (req, res) => {
    try {
        const userCode = req.headers.user_code
        const response = await placesService.addPlaces(req.body, userCode)
        return res.status(httpStatusCode.OK).send(responseGenerators(response, httpStatusCode.OK, 'Place added successfully', false))
    } catch (error) {
        logger.warn(`Error while add places. Error: %j %s`, error, error)
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, 'Error while add places', true))
    }
}

const editPlaces = async (req, res) => {
    try {
        const userCode = req.headers.user_code
        const placeId = req.params.place_id
        const response = await placesService.editPlaces(req.body, placeId, userCode)
        if(response.nModified === 0) {
            return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, 'You are not allowed to do this action', false))
        }
        return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, 'Place edited successfully', false))
    } catch (error) {
        logger.warn(`Error while edit places. Error: %j %s`, error, error)
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, 'Error while edit places', true))
    }
}

module.exports = {
    fetchPlaces,
    addPlaces,
    editPlaces
}