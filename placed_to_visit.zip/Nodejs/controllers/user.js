const userService = require('../services/user')
const httpStatusCode = require('http-status-codes')
const { responseGenerators, bcrypt, generateToken, pino } = require('./../lib/utils')
const logger = pino({ level: 'debug' });

const userSignup = async (req, res) => {
    try {
        req.body.password = bcrypt.hashSync(req.body.password, 10)
        const response = await userService.insertUserData(req.body)
        const token = generateToken(response[0], response[0].user_id)
        return res.status(httpStatusCode.OK).send(responseGenerators(response, httpStatusCode.OK, 'User registered successfully', false, token))
    } catch (error) {
        logger.warn(`Error while registering user. Error: %j %s`, error, error)
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, 'Error while user signup', true))
    }
}

const userLogin = async (req, res) => {
    try {
        const response = await userService.userLogin(req.body)
        if (Array.isArray(response) && response.length > 0) {
            const token = generateToken(response[0], response[0].user_id)
            return res.status(httpStatusCode.OK).send(responseGenerators(response, httpStatusCode.OK, 'User logged in successfully', false, token))
        }
        return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, response, false))
    } catch (error) {
        logger.warn(`Error while loging user. Error: %j %s`, error, error)
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, 'Error while user login', true))
    }
}

module.exports = {
    userSignup,
    userLogin
}